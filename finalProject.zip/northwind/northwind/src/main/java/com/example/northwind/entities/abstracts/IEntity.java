package com.example.northwind.entities.abstracts;

public interface IEntity {

}
